﻿using DotnetCoreMVC_EFCRUD.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DotnetCoreMVC_EFCRUD.Controllers
{
    public class EmpAsyncController : Controller
    {
        private readonly EmpDbContext context;

        public EmpAsyncController(EmpDbContext context)
        {
            this.context = context;
        }
        // GET: EmpAsyncController
        public async Task<ActionResult> Index()
        { 
            return View(await context.Emps.ToListAsync());
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
                return BadRequest();//400
            var emp =await context.Emps.FindAsync(id);
            if (emp == null)
                return NotFound();//404
            return View(emp);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Emp emp)
        {
            if (ModelState.IsValid)
            {
                await context.Emps.AddAsync(emp);
                await context.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(emp);
        }
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
                return BadRequest();//400
            var emp = await context.Emps.FindAsync(id);
            if (emp == null)
                return NotFound();//404
            return View(emp);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Emp emp)
        {
            if (ModelState.IsValid)
            {
                context.Emps.Update(emp);
                await context.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(emp);
        }
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
                return BadRequest();//400
            var emp = await context.Emps.FindAsync(id);
            if (emp == null)
                return NotFound();//404
            return View(emp);
        }
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var emp =await context.Emps.FindAsync(id);
            context.Emps.Remove(emp);
            await context.SaveChangesAsync();
            return RedirectToAction("Index");
        }
    }
}
