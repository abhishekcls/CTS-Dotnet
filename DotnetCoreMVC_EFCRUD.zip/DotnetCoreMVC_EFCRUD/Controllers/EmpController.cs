﻿using DotnetCoreMVC_EFCRUD.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DotnetCoreMVC_EFCRUD.Controllers
{
    [Authorize]
    public class EmpController : Controller
    {
        private readonly EmpDbContext context;

        public EmpController(EmpDbContext context)
        {
            this.context = context;
        }
        [AllowAnonymous]
        public IActionResult Index()
        {
            return View(context.Emps.ToList());
        }

        public IActionResult Details(int? id)
        {
            if (id == null)
                return BadRequest();//400
            var emp = context.Emps.Find(id);
            if (emp == null)
                return NotFound();//404
            return View(emp);
        }
        public IActionResult Delete(int? id)
        {
            if (id == null)
                return BadRequest();//400
            var emp = context.Emps.Find(id);
            if (emp == null)
                return NotFound();//404
            return View(emp);
        }
        [HttpPost,ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var emp = context.Emps.Find(id);
            context.Emps.Remove(emp);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult Edit(int? id)
        {
            if (id == null)
                return BadRequest();//400
            var emp = context.Emps.Find(id);
            if (emp == null)
                return NotFound();//404
            return View(emp);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id,Emp emp)
        {
            if (ModelState.IsValid)
            {
                context.Emps.Update(emp);
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(emp);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Emp emp)
        {
            if (ModelState.IsValid)
            {
                context.Emps.Add(emp);
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(emp);
        }
    }
}
