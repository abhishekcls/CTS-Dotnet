﻿using System.ComponentModel.DataAnnotations;

namespace DotnetCoreMVC_EFCRUD.Models
{
    public class Emp
    {
        [Key]
        public int EID { get; set; }
        [Required]
        [StringLength(15,MinimumLength =2)]
        public string EName { get; set; }
        [Range(10000,90000)]
        public int ESal { get; set; }
    }
}
